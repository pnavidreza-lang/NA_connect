import 'package:flutter/material.dart';

class NA {
  static const bg = Color(0xFF080B12);
  static const navy = Color(0xFF101B30);
  static const blue = Color(0xFF1677FF);
  static const cyan = Color(0xFF54D6FF);

  static ThemeData dark() => ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: const ColorScheme.dark(
            primary: blue, secondary: cyan, surface: navy),
        appBarTheme: const AppBarTheme(
            backgroundColor: bg, elevation: 0, centerTitle: true),
        useMaterial3: true,
      );
}
