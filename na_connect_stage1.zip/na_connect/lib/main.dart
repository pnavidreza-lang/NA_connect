import 'package:flutter/material.dart';
import 'core/theme.dart';
import 'modules/connection/nearby_service.dart';
import 'modules/nearby/nearby_screen.dart';

void main() => runApp(const App());

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'NA_CONNECT',
        debugShowCheckedModeBanner: false,
        theme: NA.dark(),
        home: NearbyScreen(NearbyService()),
      );
}
