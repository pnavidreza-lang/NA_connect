import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:nearby_connections/nearby_connections.dart';
import 'package:permission_handler/permission_handler.dart';

class Msg {
  final String text;
  final bool mine;
  final DateTime time;
  Msg(this.text, this.mine) : time = DateTime.now();
}

/// Offline P2P link (Bluetooth + Wi-Fi) using Google Nearby Connections.
class NearbyService extends ChangeNotifier {
  static const serviceId = 'com.naconnect.app';
  final _n = Nearby();
  String myName = 'NA_user';
  bool running = false;
  String? error;

  final found = <String, String>{};
  final pending = <String, String>{};
  final connected = <String, String>{};
  final messages = <String, List<Msg>>{};

  Future<bool> _perms() async {
    final r = await [
      Permission.location,
      Permission.bluetoothScan,
      Permission.bluetoothAdvertise,
      Permission.bluetoothConnect,
      Permission.nearbyWifiDevices,
    ].request();
    return r[Permission.location]?.isGranted ?? false;
  }

  Future<void> start(String name) async {
    myName = name;
    error = null;
    if (!await _perms()) {
      error = 'مجوزها داده نشد';
      notifyListeners();
      return;
    }
    try {
      await _n.startAdvertising(myName, Strategy.P2P_CLUSTER,
          onConnectionInitiated: _onInit,
          onConnectionResult: _onResult,
          onDisconnected: _onDisc,
          serviceId: serviceId);
      await _n.startDiscovery(myName, Strategy.P2P_CLUSTER,
          onEndpointFound: (id, n, s) {
            found[id] = n;
            notifyListeners();
          },
          onEndpointLost: (id) {
            found.remove(id);
            notifyListeners();
          },
          serviceId: serviceId);
      running = true;
    } catch (e) {
      error = '$e';
    }
    notifyListeners();
  }

  Future<void> stop() async {
    await _n.stopAdvertising();
    await _n.stopDiscovery();
    await _n.stopAllEndpoints();
    running = false;
    found.clear();
    connected.clear();
    pending.clear();
    notifyListeners();
  }

  Future<void> connect(String id) async {
    try {
      await _n.requestConnection(myName, id,
          onConnectionInitiated: _onInit,
          onConnectionResult: _onResult,
          onDisconnected: _onDisc);
    } catch (e) {
      error = '$e';
      notifyListeners();
    }
  }

  void _onInit(String id, ConnectionInfo info) {
    pending[id] = info.endpointName;
    notifyListeners();
  }

  Future<void> accept(String id) async {
    await _n.acceptConnection(id, onPayLoadRecieved: (eid, p) {
      if (p.type == PayloadType.BYTES && p.bytes != null) {
        (messages[eid] ??= []).add(Msg(utf8.decode(p.bytes!), false));
        notifyListeners();
      }
    }, onPayloadTransferUpdate: (eid, u) {});
  }

  Future<void> reject(String id) async {
    await _n.rejectConnection(id);
    pending.remove(id);
    notifyListeners();
  }

  void _onResult(String id, Status s) {
    final name = pending.remove(id) ?? found[id] ?? id;
    if (s == Status.CONNECTED) connected[id] = name;
    notifyListeners();
  }

  void _onDisc(String id) {
    connected.remove(id);
    notifyListeners();
  }

  Future<void> send(String id, String text) async {
    if (text.trim().isEmpty) return;
    await _n.sendBytesPayload(id, Uint8List.fromList(utf8.encode(text)));
    (messages[id] ??= []).add(Msg(text, true));
    notifyListeners();
  }
}
