import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../connection/nearby_service.dart';

class ChatScreen extends StatefulWidget {
  final NearbyService svc;
  final String id, name;
  const ChatScreen(this.svc, this.id, this.name, {super.key});
  @override
  State<ChatScreen> createState() => _C();
}

class _C extends State<ChatScreen> {
  final _t = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: widget.svc,
      builder: (ctx, _) {
        final msgs = widget.svc.messages[widget.id] ?? [];
        final online = widget.svc.connected.containsKey(widget.id);
        return Directionality(
          textDirection: TextDirection.rtl,
          child: Scaffold(
            appBar:
                AppBar(title: Text(widget.name + (online ? '' : ' (قطع)'))),
            body: Column(children: [
              Expanded(
                child: ListView.builder(
                  reverse: true,
                  padding: const EdgeInsets.all(12),
                  itemCount: msgs.length,
                  itemBuilder: (_, i) {
                    final m = msgs[msgs.length - 1 - i];
                    return Align(
                      alignment: m.mine
                          ? Alignment.centerLeft
                          : Alignment.centerRight,
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: 4),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 10),
                        decoration: BoxDecoration(
                          color: m.mine ? NA.blue : NA.navy,
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Text(m.text),
                      ),
                    );
                  },
                ),
              ),
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(8),
                  child: Row(children: [
                    Expanded(
                      child: TextField(
                        controller: _t,
                        decoration: const InputDecoration(
                            hintText: 'پیام...',
                            border: OutlineInputBorder()),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.send, color: NA.cyan),
                      onPressed: online
                          ? () {
                              widget.svc.send(widget.id, _t.text);
                              _t.clear();
                            }
                          : null,
                    ),
                  ]),
                ),
              ),
            ]),
          ),
        );
      },
    );
  }
}
