import 'package:flutter/material.dart';
import '../../core/theme.dart';
import '../connection/nearby_service.dart';
import '../messaging/chat_screen.dart';

class NearbyScreen extends StatefulWidget {
  final NearbyService svc;
  const NearbyScreen(this.svc, {super.key});
  @override
  State<NearbyScreen> createState() => _S();
}

class _S extends State<NearbyScreen> {
  final _name = TextEditingController(text: 'NA_maker');
  NearbyService get s => widget.svc;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: s,
      builder: (ctx, _) => Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(title: const Text('NA_CONNECT')),
          body: ListView(padding: const EdgeInsets.all(16), children: [
            TextField(
              controller: _name,
              enabled: !s.running,
              decoration: const InputDecoration(
                  labelText: 'نام مستعار', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: () =>
                  s.running ? s.stop() : s.start(_name.text.trim()),
              child: Text(s.running
                  ? 'توقف و مخفی شدن'
                  : 'جست‌وجوی دستگاه‌های نزدیک'),
            ),
            if (s.error != null)
              Padding(
                padding: const EdgeInsets.all(8),
                child: Text(s.error!,
                    style: const TextStyle(color: Colors.redAccent)),
              ),
            if (s.pending.isNotEmpty) _head('درخواست‌های اتصال'),
            for (final e in s.pending.entries)
              Card(
                color: NA.navy,
                child: ListTile(
                  title: Text(e.value),
                  subtitle: const Text('درخواست اتصال'),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                    IconButton(
                        icon: const Icon(Icons.check, color: NA.cyan),
                        onPressed: () => s.accept(e.key)),
                    IconButton(
                        icon: const Icon(Icons.close, color: Colors.redAccent),
                        onPressed: () => s.reject(e.key)),
                  ]),
                ),
              ),
            if (s.connected.isNotEmpty) _head('متصل'),
            for (final e in s.connected.entries)
              Card(
                color: NA.navy,
                child: ListTile(
                  leading: const Icon(Icons.chat_bubble, color: NA.blue),
                  title: Text(e.value),
                  onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => ChatScreen(s, e.key, e.value))),
                ),
              ),
            if (s.found.isNotEmpty) _head('دستگاه‌های نزدیک'),
            for (final e in s.found.entries)
              if (!s.connected.containsKey(e.key))
                Card(
                  color: NA.navy,
                  child: ListTile(
                    leading: const Icon(Icons.wifi_tethering, color: NA.cyan),
                    title: Text(e.value),
                    trailing: TextButton(
                        onPressed: () => s.connect(e.key),
                        child: const Text('اتصال')),
                  ),
                ),
          ]),
        ),
      ),
    );
  }

  Widget _head(String t) => Padding(
      padding: const EdgeInsets.fromLTRB(4, 20, 4, 8),
      child: Text(t, style: const TextStyle(color: NA.cyan)));
}
